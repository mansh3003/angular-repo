export const environment = {
    production: true,
    node_env: 'test',
    oktaEnabled: true,
    oktaIssuer: 'https://modernatx.okta.com/oauth2/default',
    oktaClientId: '0oa1646kkcycwFlAH2p8',
    oktaRedirectUri: window.location.origin + '/login/callback',
};
