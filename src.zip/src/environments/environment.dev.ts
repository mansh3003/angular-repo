export const environment = {
    production: false,
    node_env: 'dev',
    oktaEnabled: true,
    oktaIssuer: 'https://modernatx.okta.com/oauth2/default',
    oktaClientId: '0oa1646kkcycwFlAH2p8',
    oktaRedirectUri: window.location.origin + '/login/callback',
};
