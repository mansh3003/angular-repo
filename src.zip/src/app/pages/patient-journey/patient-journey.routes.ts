import type { Routes } from '@angular/router';
import { PatientJourneyComponent } from './patient-journey.component';

export const routes: Routes = [
    {
        path: '',
        component: PatientJourneyComponent,
    },
];
