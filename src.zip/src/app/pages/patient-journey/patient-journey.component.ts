import { CommonModule } from '@angular/common';
import {
    ChangeDetectionStrategy,
    Component,
    CUSTOM_ELEMENTS_SCHEMA,
} from '@angular/core';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';

@Component({
    selector: 'app-patient-journey',
    standalone: true,
    imports: [CommonModule, FontAwesomeModule],
    templateUrl: './patient-journey.component.html',
    styleUrls: ['./patient-journey.component.scss'],
    schemas: [CUSTOM_ELEMENTS_SCHEMA],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class PatientJourneyComponent {

}
