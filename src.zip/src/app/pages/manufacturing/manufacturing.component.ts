import { CommonModule } from '@angular/common';
import {
    ChangeDetectionStrategy,
    Component,
    CUSTOM_ELEMENTS_SCHEMA,
} from '@angular/core';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';

@Component({
    selector: 'app-manufacturing',
    standalone: true,
    imports: [CommonModule, FontAwesomeModule],
    templateUrl: './manufacturing.component.html',
    styleUrls: ['./manufacturing.component.scss'],
    schemas: [CUSTOM_ELEMENTS_SCHEMA],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ManufacturingComponent {
    public activeTab: 'tat' | 'process' | 'equipment' = 'tat';

    dashboardUrls: Record<string, string> = {
        tat: 'https://prod-useast-b.online.tableau.com/t/moderna/views/INTTATAnalysiswithCDFMockdata1/Summary',
        process:
            'https://prod-useast-b.online.tableau.com/t/yourOrg/views/processDashboardName/Sheet1',
        equipment:
            'https://prod-useast-b.online.tableau.com/t/moderna/views/ManufacturingEquipmentStatusDashboard/PROCESS',
    };

    get activeDashboardUrl(): string {
        return this.dashboardUrls[this.activeTab];
    }

    switchTab(tab: 'tat' | 'process' | 'equipment') {
        this.activeTab = tab;
    }
}
