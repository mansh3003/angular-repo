import type { Routes } from '@angular/router';
import { ManufacturingComponent } from './manufacturing.component';

export const routes: Routes = [
    {
        path: '',
        component: ManufacturingComponent,
    },
];
