import { CommonModule } from '@angular/common';
import {
    ChangeDetectionStrategy,
    Component,
    CUSTOM_ELEMENTS_SCHEMA,
} from '@angular/core';

@Component({
    selector: 'app-qc',
    standalone: true,
    imports: [CommonModule],
    templateUrl: './qc.component.html',
    styleUrls: ['./qc.component.scss'],
    schemas: [CUSTOM_ELEMENTS_SCHEMA],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class QCComponent {
    public activeTab: 'equipment' | 'batch' | 'coa' = 'equipment';

    dashboardUrls: Record<string, string> = {
        equipment:
            'https://prod-useast-b.online.tableau.com/t/moderna/views/QCEquipmentStatus_Final_v1/SUMMARY',
        //batch: 'https://prod-useast-b.online.tableau.com/t/moderna/views/QCBatchTrackersampledata/SUMMARY',
        batch:'https://prod-useast-b.online.tableau.com/t/moderna/views/QCBatchTrackerwithCDFmockdata/SUMMARY',
        //coa: 'https://prod-useast-b.online.tableau.com/t/moderna/views/QCCOADashboardsampledata/MonthlySummary',
        coa:'https://prod-useast-b.online.tableau.com/t/moderna/views/QCCOADashboardwithCDFMockdata/MonthlySummary'
    };

    get activeDashboardUrl(): string {
        return this.dashboardUrls[this.activeTab];
    }

    switchTab(tab: 'equipment' | 'batch' | 'coa') {
        this.activeTab = tab;
    }
}
