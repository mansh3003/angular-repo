import type { Routes } from '@angular/router';
import { QCComponent } from './qc.component';

export const routes: Routes = [
    {
        path: '',
        component: QCComponent,
    },
];
