import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component } from '@angular/core';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
// import { AbstractComponent } from '@mtx/angular-core';

@Component({
    selector: 'app-home-page',
    standalone: true,
    imports: [CommonModule, FontAwesomeModule],
    templateUrl: './home-page.component.html',
    styleUrls: ['./home-page.component.scss'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class HomePageComponent {}
