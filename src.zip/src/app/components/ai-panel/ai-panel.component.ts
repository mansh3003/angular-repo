import { CommonModule } from '@angular/common';
import {
    ChangeDetectionStrategy,
    Component,
    EventEmitter,
    Input,
    Output,
} from '@angular/core';
import { Router, RouterModule } from '@angular/router';
 import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
// import { AbstractComponent } from '@mtx/angular-core';

@Component({
    selector: 'app-ai-panel',
    standalone: true,
    imports: [CommonModule, FontAwesomeModule, RouterModule],
    templateUrl: './ai-panel.component.html',
    styleUrls: ['./ai-panel.component.scss'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AiPanelComponent {
    @Input() isOpen: boolean = false;
    @Output() toggle = new EventEmitter<void>();

    togglePanel() {
        this.toggle.emit();
    }
}
