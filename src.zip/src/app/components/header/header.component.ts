import { CommonModule } from '@angular/common';
import {
    ChangeDetectionStrategy,
    Component,
    EventEmitter,
    Output,
} from '@angular/core';
 import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { environment } from '../../../environments/environment';
 //import { OktaAuthStateService, OktaAuthService } from '@okta/okta-angular';
// import { AbstractComponent } from '@mtx/angular-core';
//import { OktaAuthService } from '@okta/okta-angular';

@Component({
    selector: 'app-header',
    standalone: true,
    imports: [CommonModule, FontAwesomeModule],
    templateUrl: './header.component.html',
    styleUrls: ['./header.component.scss'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class HeaderComponent {

    constructor(
    // private oktaAuth: OktaAuthService,
    // private authStateService: OktaAuthStateService
  ) {
    // this.authStateService.authState$
    //   .pipe(filter(authState => !!authState))
    //   .subscribe((authState) => this.isAuthenticated = !!authState.isAuthenticated);
  }
    @Output() aiToggle = new EventEmitter<void>();

    showProfileModal = false;
    userName = 'John Doe'; // Replace with actual user name from your auth service

    openProfileModal() {
        this.showProfileModal = true;
    }

    closeProfileModal() {
        this.showProfileModal = false;
    }

    logout() {
       // Replace these with your actual Okta domain and client ID
    const oktaDomain = environment.oktaIssuer;
    const postLogoutRedirectUri = window.location.origin;
    window.location.href = `${oktaDomain}/oauth2/default/v1/logout?id_token_hint=&post_logout_redirect_uri=${postLogoutRedirectUri}`;
    }

}
