import { DatePipe } from '@angular/common';
import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { HeaderComponent } from './components/header/header.component';
import { SidebarComponent } from './components/sidebar/sidebar.component';
import { CoreModule } from './core.module';
import { AiPanelComponent } from './components/ai-panel/ai-panel.component';

@Component({
    standalone: true,
    imports: [
        RouterOutlet,
        CoreModule,
        SidebarComponent,
        HeaderComponent,
        AiPanelComponent,
    ],
    // Providing the config service here ensures that this app's config overrides the host app's config when this root component is imported and rendered in the host app;
    // note that with the current configuration of mtx-navbar, clicking the app title will always navigate to the host app's root route, not this app's root
    // providers: [
    //     { provide: CONFIG_SERVICE, useExisting: ConfigService },
    //     DatePipe,
    // ],
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.scss'],
})
export class AppComponent {
    isAiPanelOpen = false;

    toggleAiPanel() {
        this.isAiPanelOpen = !this.isAiPanelOpen;
    }
}
