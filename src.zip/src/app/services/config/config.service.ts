// import { Injectable } from '@angular/core';
// import { AbstractConfigService } from '@mtx/angular-core';
// import type { Config } from './config';
// import { CONFIG } from './config';

// @Injectable({
//     providedIn: 'root',
// })
// export class ConfigService extends AbstractConfigService<Config> {
//     public constructor() {
//         super(CONFIG);
//     }
// }
