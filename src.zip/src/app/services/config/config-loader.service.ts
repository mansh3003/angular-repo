// import { HttpClient } from '@angular/common/http';
// import { Injectable } from '@angular/core';
// import type { Observable } from 'rxjs';
// import { tap } from 'rxjs';
// import type { User } from '@mtx/angular-users';
// import { UserService } from '@mtx/angular-users';
// import { CONFIG } from './config';
// import type { Config } from './config';
// import { ConfigService } from './config.service';

// @Injectable({ providedIn: 'root' })
// export class ConfigLoader {
//     config: Config = CONFIG;
//     constructor(
//         private readonly userService: UserService,
//         private readonly http: HttpClient,
//         private readonly configService: ConfigService
//     ) {}

//     loadUser(): Observable<User> {
//         return this.http.get<User>('api/current-user').pipe(
//             tap((user: User) => {
//                 this.userService.currentUser = user;
//             })
//         );
//     }

//     loadRevision(): Observable<string> {
//         return this.http.get<string>('rest/revision').pipe(
//             tap((revision: string) => {
//                 this.configService.config.revision = revision;
//             })
//         );
//     }
// }
