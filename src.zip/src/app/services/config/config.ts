// import type { BaseConfig } from '@mtx/angular-core';
// import { environment } from '../../../environments/environment';

// // define this app's config by extending @mtx configs to ensure configuration
// type appPermission = 'viewManageUsersPage';

// export interface Config extends BaseConfig {
//     agGridLicenseKey?: string;
//     permissions: Record<
//         appPermission,
//         {
//             app: string;
//             description: string;
//             name: string;
//             context?: object;
//         }
//     >;
// }

// export const CONFIG: Config = {
//     app: {
//         title: 'ControlTower',
//     },
//     env: environment.node_env,
//     footer: {
//         // TODO documentationUrl: 'https://confluence.modernatx.net/display/AD/ControlTower+App',
//         // TODO questionsUrl: 'https://confluence.modernatx.net/display/AD/ControlTower+App',
//     },
//     name: 'control-tower',
//     navbar: {
//         title: 'ControlTower',
//         iconBackgroundColor: '#76ca2c',
//         // TODO documentationUrl: 'https://confluence.modernatx.net/display/AD/ControlTower+App',
//         // TODO questionsUrl: 'https://confluence.modernatx.net/display/AD/ControlTower+App',
//         hideNotifications: true,
//         routes: [
//             {
//                 path: 'access',
//                 title: 'Access',
//                 // TODO isPermitted: {
//                 //     permissionName: 'view-manage-users-page',
//                 // },
//             },
//         ],
//     },
//     permissions: {
//         // Used for Access page
//         viewManageUsersPage: {
//             app: 'control-tower',
//             description: 'View Manage Users Page',
//             name: 'viewManageUsersPage',
//         },
//     },
//     revision: '',
// };
