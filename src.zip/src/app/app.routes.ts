import type { Routes } from '@angular/router';
import { PatientJourneyComponent } from './pages/patient-journey/patient-journey.component';
import { ManufacturingComponent } from './pages/manufacturing/manufacturing.component';
import { OktaAuthModule } from '@okta/okta-angular';
//import { OktaAuthGuard, OktaCallbackComponent } from '@okta/okta-angular';
import { OktaCallbackComponent, OktaAuthGuard } from '@okta/okta-angular';
import { environment } from '../environments/environment';

export const routes: Routes = [
    {
        path: '',
        pathMatch: 'full',
        redirectTo: 'home',
    },
   {
    path: 'login/callback',
    component: OktaCallbackComponent,
   },
    {
        path: 'home',
        loadChildren: () =>
            import('./pages/home/home-page.routes').then(
                (module) => module.routes
            ),
        canActivate: environment.oktaEnabled ? [OktaAuthGuard] : [],
    },
    {
        path: 'patient-journey',
        component: PatientJourneyComponent,
    },
    {
        path: 'manufacturing',
        component: ManufacturingComponent,
    },
    {
        path: 'qc',
        loadChildren: () =>
            import('./pages/QC/qc.routes').then((module) => module.routes),
    },
    {
        path: '**',
        // NOTE: This is the redirect to looking glass not found page
        redirectTo: '/page-not-found',
    },
];
