import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { OktaAuthModule, OKTA_CONFIG } from '@okta/okta-angular';
import { OktaAuth } from '@okta/okta-auth-js';
import { environment } from '../environments/environment';

// const oktaAuthold = new OktaAuth({
// //     issuer: 'https://integrator-5160821.okta.com/oauth2/default',
// //   clientId: '0oatnc14pmlHXQwei697',
// //   redirectUri: 'http://localhost:4200/login/callback',
// //   scopes: ['openid', 'profile', 'email'],
// //   pkce: true,
// issuer: 'https://integrator-2998127.okta.com/oauth2/default',
//   clientId: '0oatwg0yckkv7RA4p697',
//   redirectUri: 'http://localhost:4200/login/callback',
//   scopes: ['openid', 'profile', 'email'],
//   pkce: true,
  
// });
const oktaAuth = environment.oktaEnabled
  ? new OktaAuth({
      issuer: environment.oktaIssuer,
      clientId: environment.oktaClientId,
      redirectUri: environment.oktaRedirectUri,
      //redirectUri: 'https://h9zffdhafp.us-east-1.awsapprunner.com/login/callback'
      scopes: ['openid', 'profile', 'email'],
      pkce: true,
    })
  : null;

@NgModule({
    imports: [CommonModule, RouterModule, ...(environment.oktaEnabled ? [OktaAuthModule] : [])],
    providers: [
        ...(environment.oktaEnabled
            ? [{ provide: OKTA_CONFIG, useValue: { oktaAuth } }]
            : []
        ),
    ],
})
export class CoreModule {}