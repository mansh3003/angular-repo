import { bootstrapApplication } from '@angular/platform-browser';
import { appConfig } from './app/app.config';
import { OKTA_CONFIG } from '@okta/okta-angular';
import { routes } from './app/app.routes';
import { AppComponent } from './app/app.component';
import { provideRouter } from '@angular/router';
import { ErrorHandler, importProvidersFrom } from '@angular/core';
import { CoreModule } from './app/core.module';



bootstrapApplication(AppComponent, {
  providers: [
    provideRouter(routes),
   importProvidersFrom(CoreModule),
        {
            provide: ErrorHandler,
            useClass: ErrorHandler,
        },
  ]
});